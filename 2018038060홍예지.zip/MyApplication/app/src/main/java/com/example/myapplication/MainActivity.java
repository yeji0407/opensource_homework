package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends AppCompatActivity {
    Button button1;
    Button button2;
    private RadioGroup rg;
    private ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1=(Button) findViewById(R.id.button1);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EditText editText=(EditText)findViewById(R.id.editText);
                Toast.makeText(getApplicationContext(), editText.getText(),
                        Toast.LENGTH_SHORT).show();
            }
        });
        button2=(Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EditText editText=(EditText)findViewById(R.id.editText);
                String str=editText.getText().toString();
                Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(str));
                startActivity(intent);
            }
        });

        rg=(RadioGroup)findViewById(R.id.radioGroup);
        img=(ImageView)findViewById(R.id.imageView);

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                String result;
                if(checkedId==R.id.radioButton){
                    img.setImageResource(R.drawable.android_pie);
                }
                else if(checkedId==R.id.radioButton2){
                    img.setImageResource(R.drawable.android_oreo);
                }
            }
        });
    }

}

